config() {
  NEW="$1"
  OLD="`dirname $NEW`/`basename $NEW .new`"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "`cat $OLD | md5sum`" = "`cat $NEW | md5sum`" ]; then # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}

preserve_perms() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  if [ -e $OLD ]; then
    cp -a $OLD ${NEW}.incoming
    cat $NEW > ${NEW}.incoming
    mv ${NEW}.incoming $NEW
  fi
  config $NEW
}

preserve_perms etc/rc.d/rc.downloadd.new
config etc/downloaddaemon/routerinfo.conf.new
config etc/downloaddaemon/downloaddaemon.conf.new
config etc/downloaddaemon/premium_accounts.conf.new

chown -R downloadd:downloadd /etc/downloaddaemon

# Add DownloadDaemon to rc.local
echo "Adding rc.downloadd entry in rc.local..."
if [ ! -f /etc/rc.d/rc.local ]; then
  echo "Nothing to do: /etc/rc.d/rc.local not found"
else
 if ! grep -q "rc.downloadd start" /etc/rc.d/rc.local && \
  grep --quiet '^downloadd:' /etc/passwd && \
   grep --quiet '^downloadd:' /etc/group; then
cat >> /etc/rc.d/rc.local << EOF

# Start the DownloadDaemon server.
#if [ -x /etc/rc.d/rc.downloadd ]; then
#  sh /etc/rc.d/rc.downloadd start
#fi

EOF
echo "New entry added in rc.local"
else
  echo "Nothing to do: rc.downloadd already in /etc/rc.d/rc.local"
 fi
fi

echo "Adding rc.downloadd entry in rc.local.shutdown..."
if [ ! -f /etc/rc.d/rc.local_shutdown ]; then
  echo "Nothing to do: /etc/rc.d/rc.local_shutdown not found"
else
 if ! grep -q "rc.downloadd stop" /etc/rc.d/rc.local_shutdown  && \
  grep --quiet '^downloadd:' /etc/passwd && \
   grep --quiet '^downloadd:' /etc/group; then
cat >> /etc/rc.d/rc.local_shutdown << EOF

# Stop the DownloadDaemon server.
#if [ -x /etc/rc.d/rc.downloadd ]; then
#  sh /etc/rc.d/rc.downloadd stop
#fi

EOF
echo "New entry added in rc.local_shutdown"
 else
  echo "Nothing to do: rc.downloadd already in /etc/rc.d/rc.local_shutdown"
 fi
fi

if [ -x /usr/bin/update-desktop-database ]; then
  /usr/bin/update-desktop-database -q usr/share/applications >/dev/null 2>&1
fi

if [ -e usr/share/icons/hicolor/icon-theme.cache ]; then
  if [ -x /usr/bin/gtk-update-icon-cache ]; then
    /usr/bin/gtk-update-icon-cache usr/share/icons/hicolor >/dev/null 2>&1
  fi
fi

# Some pimp
if [ -f /usr/bin/tput ] && \
   grep --quiet '^downloadd:' /etc/passwd && \
    grep --quiet '^downloadd:' /etc/group ; then
  /usr/bin/tput bold
  echo ""
  echo "DownloadDaemon will run as:"
  echo ""
  echo "User: DownloadDaemon user"
  echo "User ID: [`grep '^downloadd:' /etc/passwd | awk -F : '{print $3}'`]"
  echo "Group: downloadd"
  echo "Group ID: [`grep '^downloadd:' /etc/group | awk -F : '{print $3}'`]"
  echo "Home: /etc/downloaddaemon"
  echo "Login shell: /bin/false"
  echo "Real name: downloadd"
  echo "Expire date: never"
  echo "Password: _blank_"
  echo ""
  /usr/bin/tput sgr0
else
 if grep --quiet '^downloadd:' /etc/passwd && \
     grep --quiet '^downloadd:' /etc/group ; then
  echo ""
  echo "DownloadDaemon will run as:"
  echo ""
  echo "User: DownloadDaemon user"
  echo "User ID: [`grep '^downloadd:' /etc/passwd | awk -F : '{print $3}'`]"
  echo "Group: downloadd"
  echo "Group ID: [`grep '^downloadd:' /etc/group | awk -F : '{print $3}'`]"
  echo "Home: /etc/downloaddaemon"
  echo "Login shell: /bin/false"
  echo "Real name: downloadd"
  echo "Expire date: never"
  echo "Password: _blank_"
  echo ""
 fi
fi
