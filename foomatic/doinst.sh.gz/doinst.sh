config() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "$(cat $OLD | md5sum)" = "$(cat $NEW | md5sum)" ]; then
    rm $NEW
  fi
}
config etc/foomatic/defaultspooler.new

if [ -r etc/foomatic/defaultspooler -a -r etc/foomatic/defaultspooler.new ]; then
  chmod --reference=etc/foomatic/defaultspooler etc/foomatic/defaultspooler.new
fi
mv etc/foomatic/defaultspooler.new etc/foomatic/defaultspooler

