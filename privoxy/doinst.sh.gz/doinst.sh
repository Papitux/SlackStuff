config() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "$(cat $OLD | md5sum)" = "$(cat $NEW | md5sum)" ]; then # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}

preserve_perms() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  if [ -e $OLD ]; then
    cp -a $OLD ${NEW}.incoming
    cat $NEW > ${NEW}.incoming
    mv ${NEW}.incoming $NEW
  fi
  config $NEW
}

# If there's no existing log file, move this one over; 
# otherwise, kill the new one
if [ ! -e var/log/privoxy/logfile ]; then
  mv var/log/privoxy/logfile.new var/log/privoxy/logfile
else
  rm -f var/log/privoxy/logfile.new
fi

preserve_perms etc/rc.d/rc.privoxy.new
config etc/privoxy/config.new
config etc/privoxy/match-all.action.new
config etc/privoxy/trust.new
config etc/privoxy/user.action.new
config etc/privoxy/user.filter.new

# These files are not intended to be edited and will be overwritten.
# To disregard, uncomment these and the .new renaming in privoxy.SlackBuild.
#config etc/privoxy/default.action.new
#config etc/privoxy/default.filter.new
#for conf_file in etc/privoxy/templates/*.new; do
#  config $conf_file
#done

# Add privoxy to rc.local
echo "Adding rc.privoxy entry in rc.local..."
if [ ! -f /etc/rc.d/rc.local ]; then
  echo "Nothing to do: /etc/rc.d/rc.local not found"
else
 if ! grep -q "rc.privoxy start" /etc/rc.d/rc.local && \
  grep --quiet '^privoxy:' /etc/passwd && \
   grep --quiet '^privoxy:' /etc/group; then
cat >> /etc/rc.d/rc.local << EOF

# Start the Privoxy web proxy daemon.
#if [ -x /etc/rc.d/rc.privoxy ]; then
#  sh /etc/rc.d/rc.privoxy start
#fi

EOF
echo "New entry added in rc.local"
else
  echo "Nothing to do: rc.privoxy already in /etc/rc.d/rc.local"
 fi
fi

# Add privoxy to rc.local.shutdown
echo "Adding rc.privoxy entry in rc.local.shutdown..."
if [ ! -f /etc/rc.d/rc.local_shutdown ]; then
  echo "Nothing to do: /etc/rc.d/rc.local_shutdown not found"
else
 if ! grep -q "rc.privoxy stop" /etc/rc.d/rc.local_shutdown  && \
  grep --quiet '^privoxy:' /etc/passwd && \
   grep --quiet '^privoxy:' /etc/group; then
cat >> /etc/rc.d/rc.local_shutdown << EOF

# Stop the Privoxy web proxy daemon.
#if [ -x /etc/rc.d/rc.privoxy ]; then
#  sh /etc/rc.d/rc.privoxy stop
#fi

EOF
echo "New entry added in rc.local_shutdown"
 else
  echo "Nothing to do: rc.privoxy already in /etc/rc.d/rc.local_shutdown"
 fi
fi

# Some pimp
if [ -f /usr/bin/tput ] && \
   grep --quiet '^privoxy:' /etc/passwd && \
    grep --quiet '^privoxy:' /etc/group ; then
  /usr/bin/tput bold
  echo ""
  echo "privoxy will run as:"
  echo ""
  echo "User: privoxy"
  echo "User ID: [`grep '^privoxy:' /etc/passwd | awk -F : '{print $3}'`]"
  echo "Group: privoxy"
  echo "Group ID: [`grep '^privoxy:' /etc/group | awk -F : '{print $3}'`]"
  echo "Home: /dev/null"
  echo "Login shell: /bin/false"
  echo "Real name: privoxy"
  echo "Expire date: never"
  echo "Password: _blank_"
  echo ""
  /usr/bin/tput sgr0
else
 if grep --quiet '^privoxy:' /etc/passwd && \
     grep --quiet '^privoxy:' /etc/group ; then
  echo ""
  echo "privoxy will run as:"
  echo ""
  echo "User: privoxy"
  echo "User ID: [`grep '^privoxy:' /etc/passwd | awk -F : '{print $3}'`]"
  echo "Group: clamav"
  echo "Group ID: [`grep '^privoxy:' /etc/group | awk -F : '{print $3}'`]"
  echo "Home: /dev/null"
  echo "Login shell: /bin/false"
  echo "Real name: privoxy"
  echo "Expire date: never"
  echo "Password: _blank_"
  echo ""
 fi
fi

