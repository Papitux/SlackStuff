config() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "$(cat $OLD | md5sum)" = "$(cat $NEW | md5sum)" ]; then
  # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}

if [ -e etc/rc.d/rc.languagetool ]; then
  cp -a etc/rc.d/rc.languagetool etc/rc.d/rc.languagetool.new.incoming
  cat etc/rc.d/rc.languagetool.new > etc/rc.d/rc.languagetool.new.incoming
  mv etc/rc.d/rc.languagetool.new.incoming etc/rc.d/rc.languagetool.new
fi

config etc/rc.d/rc.languagetool.new

# Add languagetool to rc.local
echo "Adding rc.languagetool entry in rc.local..."
if [ ! -f /etc/rc.d/rc.local ]; then
  echo "Nothing to do: /etc/rc.d/rc.local not found"
else
 if ! grep -q "rc.languagetool start" /etc/rc.d/rc.local ; then
cat >> /etc/rc.d/rc.local << EOF

# Start LanguageTool HTTPServer:
#if [ -x /etc/rc.d/rc.languagetool ]; then
#  sh /etc/rc.d/rc.languagetool start
#fi

EOF
echo "New entry added in rc.local"
else
  echo "Nothing to do: rc.languagetool already in /etc/rc.d/rc.local"
 fi
fi

# Add languagetool to rc.local.shutdown
echo "Adding rc.languagetool entry in rc.local.shutdown..."
if [ ! -f /etc/rc.d/rc.local_shutdown ]; then
  echo "Nothing to do: /etc/rc.d/rc.local_shutdown not found"
else
 if ! grep -q "rc.languagetool stop" /etc/rc.d/rc.local_shutdown ; then
cat >> /etc/rc.d/rc.local_shutdown << EOF

# Stop LanguageTool HTTPServer:
#if [ -x /etc/rc.d/rc.languagetool ]; then
#  sh /etc/rc.d/rc.languagetool stop
#fi

EOF
echo "New entry added in rc.local_shutdown"
 else
  echo "Nothing to do: rc.languagetool already in /etc/rc.d/rc.local_shutdown"
 fi
fi

if [ -x /usr/bin/update-desktop-database ]; then
  /usr/bin/update-desktop-database -q usr/share/applications >/dev/null 2>&1
fi

if [ -e usr/share/icons/hicolor/icon-theme.cache ]; then
  if [ -x /usr/bin/gtk-update-icon-cache ]; then
    /usr/bin/gtk-update-icon-cache usr/share/icons/hicolor >/dev/null 2>&1
  fi
fi

