config() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "$(cat $OLD | md5sum)" = "$(cat $NEW | md5sum)" ]; then
    # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}
preserve_perms() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  if [ -e $OLD ]; then
    cp -a $OLD ${NEW}.incoming
    cat $NEW > ${NEW}.incoming
    mv ${NEW}.incoming $NEW
  fi
  config $NEW
}
config etc/sphinx/sphinx.conf.dist.new
config etc/sphinx/sphinx-min.conf.dist.new
preserve_perms etc/rc.d/rc.sphinx.new

# Add sphinx to rc.local
echo "Adding rc.sphinx entry in rc.local..."
if [ ! -f /etc/rc.d/rc.local ]; then
  echo "Nothing to do: /etc/rc.d/rc.local not found"
else
 if ! grep -q "rc.sphinx start" /etc/rc.d/rc.local ; then
cat >> /etc/rc.d/rc.local << EOF

# Start the database search daemon (sphinx):
#if [ -x /etc/rc.d/rc.sphinx ]; then
#  sh /etc/rc.d/rc.sphinx start
#fi

EOF
echo "New entry added in rc.local"
else
  echo "Nothing to do: rc.sphinx already in /etc/rc.d/rc.local"
 fi
fi

# Add sphinx to rc.local.shutdown
echo "Adding rc.sphinx entry in rc.local.shutdown..."
if [ ! -f /etc/rc.d/rc.local_shutdown ]; then
  echo "Nothing to do: /etc/rc.d/rc.local_shutdown not found"
else
 if ! grep -q "rc.sphinx stop" /etc/rc.d/rc.local_shutdown ; then
cat >> /etc/rc.d/rc.local_shutdown << EOF

# Stop the database search daemon (sphinx):
#if [ -x /etc/rc.d/rc.sphinx ]; then
#  sh /etc/rc.d/rc.sphinx stop
#fi

EOF
echo "New entry added in rc.local_shutdown"
 else
  echo "Nothing to do: rc.sphinx already in /etc/rc.d/rc.local_shutdown"
 fi
fi

# Some pimp
if [ -f /usr/bin/tput ] && \
   grep --quiet '^sphinx:' /etc/passwd && \
    grep --quiet '^sphinx:' /etc/group ; then
  /usr/bin/tput bold
  echo ""
  echo "sphinx will run as:"
  echo ""
  echo "User: Sphinx search"
  echo "User ID: [`grep '^sphinx:' /etc/passwd | awk -F : '{print $3}'`]"
  echo "Group: sphinx"
  echo "Group ID: [`grep '^sphinx:' /etc/group | awk -F : '{print $3}'`]"
  echo "Home: /var/lib/sphinx"
  echo "Login shell: /bin/false"
  echo "Real name: sphinx"
  echo "Expire date: never"
  echo "Password: _blank_"
  echo ""
  /usr/bin/tput sgr0
else
 if grep --quiet '^sphinx:' /etc/passwd && \
     grep --quiet '^sphinx:' /etc/group ; then
  echo ""
  echo "sphinx will run as:"
  echo ""
  echo "User: Sphinx search"
  echo "User ID: [`grep '^sphinx:' /etc/passwd | awk -F : '{print $3}'`]"
  echo "Group: clamav"
  echo "Group ID: [`grep '^sphinx:' /etc/group | awk -F : '{print $3}'`]"
  echo "Home: /var/lib/sphinx"
  echo "Login shell: /bin/false"
  echo "Real name: sphinx"
  echo "Expire date: never"
  echo "Password: _blank_"
  echo ""
 fi
fi
