config() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "$(cat $OLD | md5sum)" = "$(cat $NEW | md5sum)" ]; then
  # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}

# Keep same perms on rc.netdata.new:
if [ -e etc/rc.d/rc.netdata ]; then
  cp -a etc/rc.d/rc.netdata etc/rc.d/rc.netdata.new.incoming
  cat etc/rc.d/rc.netdata.new > etc/rc.d/rc.netdata.new.incoming
  mv etc/rc.d/rc.netdata.new.incoming etc/rc.d/rc.netdata.new
fi
# Then go for it
config etc/rc.d/rc.netdata.new

# For single config files
config etc/netdata/daemon.conf.new
config etc/netdata/charts.d.conf.new
config etc/netdata/apps_groups.conf.new

# Some useful information
if [ -f /usr/bin/tput ] ; then
  /usr/bin/tput bold
fi
  echo ""
  echo "After the daemon has been started for the first time, download the"
  echo "default config file from: http://127.0.0.1:19999/netdata.conf"
  echo ""
  echo "Copy it to /etc/netdata/ and modify it."
  echo ""
if [ -f /usr/bin/tput ] ; then
  /usr/bin/tput sgr0
fi

# More useful information
if [ -f /usr/bin/tput ] ; then
  /usr/bin/tput bold
fi
#
if [ -e "/sys/kernel/mm/ksm/run" ] ; then
  echo "INFORMATION:"
  echo ""
  echo "I see you have kernel memory de-duper (called Kernel Same-page Merging,"
  echo "or KSM) available, but it is not currently enabled."
  echo ""
  echo "To enable it run:"
  echo ""
  echo "echo 1 >/sys/kernel/mm/ksm/run"
  echo "echo 1000 >/sys/kernel/mm/ksm/sleep_millisecs"
  echo  ""
  echo "If you enable it, you will save 20-60% of netdata memory."
  echo  ""
else
  echo "INFORMATION:"
  echo ""
  echo "I see you do not have kernel memory de-duper (called Kernel Same-page"
  echo "Merging, or KSM) available."
  echo ""
  echo "To enable it, you need a kernel built with CONFIG_KSM=y"
  echo ""
  echo "If you can have it, you will save 20-60% of netdata memory."
  echo  ""
 fi
#
if [ -f /usr/bin/tput ] ; then
  /usr/bin/tput sgr0
fi

