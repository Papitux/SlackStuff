config() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "$(cat $OLD | md5sum)" = "$(cat $NEW | md5sum)" ]; then
    # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}

preserve_perms() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  if [ -e $OLD ]; then
    cp -a $OLD ${NEW}.incoming
    cat $NEW > ${NEW}.incoming
    mv ${NEW}.incoming $NEW
  fi
  config $NEW
}

config etc/dnsextd.conf.new
config etc/mDNSResponder.conf.new
config etc/nss_mdns.conf.new
preserve_perms etc/rc.d/rc.mDNSResponder.new

# Add mDNSResponder to rc.local
echo "Adding rc.mDNSResponder entry in rc.local..."
if [ ! -f /etc/rc.d/rc.local ]; then
  echo "Nothing to do: /etc/rc.d/rc.local not found"
else
 if ! grep -q "rc.mDNSResponder start" /etc/rc.d/rc.local ; then
cat >> /etc/rc.d/rc.local << EOF

# Start the mDNS Responder daemon (mDNSResponder):
#if [ -x /etc/rc.d/rc.mDNSResponder ]; then
#  sh /etc/rc.d/rc.mDNSResponder start
#fi

EOF
echo "New entry added in rc.local"
else
  echo "Nothing to do: rc.mDNSResponder already in /etc/rc.d/rc.local"
 fi
fi

echo "Adding rc.mDNSResponder entry in rc.local.shutdown..."
if [ ! -f /etc/rc.d/rc.local_shutdown ]; then
  echo "Nothing to do: /etc/rc.d/rc.local_shutdown not found"
else
 if ! grep -q "rc.mDNSResponder stop" /etc/rc.d/rc.local_shutdown ; then
cat >> /etc/rc.d/rc.local_shutdown << EOF

# Stop the mDNS Responder daemon (mDNSResponder):
#if [ -x /etc/rc.d/rc.mDNSResponder ]; then
#  sh /etc/rc.d/rc.mDNSResponder stop
#fi

EOF
echo "New entry added in rc.local_shutdown"
 else
  echo "Nothing to do: rc.mDNSResponder already in /etc/rc.d/rc.local_shutdown"
 fi
fi

# Some pimp
if [ -f /usr/bin/tput ]; then
 /usr/bin/tput bold
 echo ""
 echo "You may need to add 'mdns' to the hosts list in /etc/nsswitch.conf"
 echo "See the file 'README.multicast' for more information"
 echo ""
  /usr/bin/tput sgr0
else
 echo ""
 echo "You may need to add 'mdns' to the hosts list in /etc/nsswitch.conf"
 echo "See the file 'README.multicast' for more information"
 echo ""
fi

