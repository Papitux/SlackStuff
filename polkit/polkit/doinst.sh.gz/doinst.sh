config() {
  NEW="$1"
  OLD="`dirname $NEW`/`basename $NEW .new`"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "`cat $OLD | md5sum`" = "`cat $NEW | md5sum`" ]; then # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}

config etc/polkit-1/rules.d/10-nm.rules.new
config etc/polkit-1/rules.d/10-power.rules.new
config etc/polkit-1/rules.d/20-disks.rules.new

#if grep --quiet '^polkitd:' /etc/group && \
#    grep --quiet '^polkitd:' /etc/passwd && \
#     [ -f /bin/chown ]; then
#  echo -e "Granting permissions to user polkitd..."  1>&2
#chroot .   /bin/chown -R polkitd:root /etc/polkit-1/rules.d
#chroot .   /bin/chown -R polkitd:root /usr/share/polkit-1/rules.d
#else
#  echo -e "Error granting permissions!"  1>&2
#fi

# Some pimp
if [ -f /usr/bin/tput ] && \
   grep --quiet '^polkitd:' /etc/passwd && \
    grep --quiet '^polkitd:' /etc/group ; then
  /usr/bin/tput bold
  echo ""
  echo "Polkitd will run as:"
  echo ""
  echo "User: polkitd"
  echo "User ID: [`grep '^polkitd:' /etc/passwd | awk -F : '{print $3}'`]"
  echo "Group: polkitd"
  echo "Group ID: [`grep '^polkitd:' /etc/group | awk -F : '{print $3}'`]"
  echo "Home: /"
  echo "Login shell: /bin/false"
  echo "Real name: Polkitd user"
  echo "Expire date: never"
  echo "Password: _blank_"
  echo ""
  /usr/bin/tput sgr0
else
 if grep --quiet '^polkitd:' /etc/passwd && \
     grep --quiet '^polkitd:' /etc/group ; then
  echo ""
  echo "Polkitd will run as:"
  echo ""
  echo "User: polkitd"
  echo "User ID: [`grep '^polkitd:' /etc/passwd | awk -F : '{print $3}'`]"
  echo "Group: polkitd"
  echo "Group ID: [`grep '^polkitd:' /etc/group | awk -F : '{print $3}'`]"
  echo "Home: /"
  echo "Login shell: /bin/false"
  echo "Real name: Polkitd user"
  echo "Expire date: never"
  echo "Password: _blank_"
  echo ""
 fi
fi
