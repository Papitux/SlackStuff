config() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "$(cat $OLD | md5sum)" = "$(cat $NEW | md5sum)" ]; then
    # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}
preserve_perms() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  if [ -e $OLD ]; then
    cp -a $OLD ${NEW}.incoming
    cat $NEW > ${NEW}.incoming
    mv ${NEW}.incoming $NEW
  fi
  config $NEW
}
config etc/pulse/client.conf.new
config etc/pulse/daemon.conf.new
config etc/pulse/default.pa.new
config etc/pulse/system.pa.new
preserve_perms etc/rc.d/rc.pulseaudio.new

# Add pulseaudio to rc.local
echo "Adding rc.pulseaudio entry in rc.local..."
if [ ! -f /etc/rc.d/rc.local ]; then
  echo "Nothing to do: /etc/rc.d/rc.local not found"
else
 if ! grep -q "rc.pulseaudio start" /etc/rc.d/rc.local ; then
cat >> /etc/rc.d/rc.local << EOF

# Start the sound server daemon (pulseaudio):
#if [ -x /etc/rc.d/rc.pulseaudio ]; then
#  sh /etc/rc.d/rc.pulseaudio start
#fi

EOF
echo "New entry added in rc.local"
else
  echo "Nothing to do: rc.pulseaudio already in /etc/rc.d/rc.local"
 fi
fi

# Add pulseaudio to rc.local.shutdown
echo "Adding rc.pulseaudio entry in rc.local.shutdown..."
if [ ! -f /etc/rc.d/rc.local_shutdown ]; then
  echo "Nothing to do: /etc/rc.d/rc.local_shutdown not found"
else
 if ! grep -q "rc.pulseaudio stop" /etc/rc.d/rc.local_shutdown ; then
cat >> /etc/rc.d/rc.local_shutdown << EOF

# Stop the sound server daemon (pulseaudio):
#if [ -x /etc/rc.d/rc.pulseaudio ]; then
#  sh /etc/rc.d/rc.pulseaudio stop
#fi

EOF
echo "New entry added in rc.local_shutdown"
 else
  echo "Nothing to do: rc.pulseaudio already in /etc/rc.d/rc.local_shutdown"
 fi
fi

# Some pimp
if [ -f /usr/bin/tput ] && \
   grep --quiet '^# Some pimp
if [ -f /usr/bin/tput ] && \
   grep --quiet '^pulse:' /etc/passwd && \
    grep --quiet '^pulse:' /etc/group ; then
  /usr/bin/tput bold
  echo ""
  echo "pulse will run as:"
  echo ""
  echo "User: Pulse user"
  echo "User ID: [`grep '^pulse:' /etc/passwd | awk -F : '{print $3}'`]"
  echo "Group: pulse"
  echo "Group ID: [`grep '^pulse:' /etc/group | awk -F : '{print $3}'`]"
  echo "Home: /var/run/pulse"
  echo "Login shell: /bin/false"
  echo "Real name: pulse"
  echo "Expire date: never"
  echo "Password: _blank_"
  echo ""
  /usr/bin/tput sgr0
else
 if grep --quiet '^pulse:' /etc/passwd && \
     grep --quiet '^pulse:' /etc/group ; then
  echo ""
  echo "pulse will run as:"
  echo ""
  echo "User: Pulse user"
  echo "User ID: [`grep '^pulse:' /etc/passwd | awk -F : '{print $3}'`]"
  echo "Group: pulse"
  echo "Group ID: [`grep '^pulse:' /etc/group | awk -F : '{print $3}'`]"
  echo "Home: /var/run/pulse"
  echo "Login shell: /bin/false"
  echo "Real name: pulse"
  echo "Expire date: never"
  echo "Password: _blank_"
  echo ""
 fi
fi
:' /etc/passwd && \
    grep --quiet '^pulse:' /etc/group ; then
  /usr/bin/tput bold
  echo ""
  echo "pulse will run as:"
  echo ""
  echo "User: Pulse user"
  echo "User ID: [`grep '^pulse:' /etc/passwd | awk -F : '{print $3}'`]"
  echo "Group: pulse"
  echo "Group ID: [`grep '^pulse:' /etc/group | awk -F : '{print $3}'`]"
  echo "Home: /var/run/pulse"
  echo "Login shell: /bin/false"
  echo "Real name: pulse"
  echo "Expire date: never"
  echo "Password: _blank_"
  echo ""
  /usr/bin/tput sgr0
else
 if grep --quiet '^pulse:' /etc/passwd && \
     grep --quiet '^pulse:' /etc/group ; then
  echo ""
  echo "pulse will run as:"
  echo ""
  echo "User: Pulse user"
  echo "User ID: [`grep '^pulse:' /etc/passwd | awk -F : '{print $3}'`]"
  echo "Group: pulse"
  echo "Group ID: [`grep '^pulse:' /etc/group | awk -F : '{print $3}'`]"
  echo "Home: /var/run/pulse"
  echo "Login shell: /bin/false"
  echo "Real name: pulse"
  echo "Expire date: never"
  echo "Password: _blank_"
  echo ""
 fi
fi

