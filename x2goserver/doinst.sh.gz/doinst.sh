config() {
  NEW="$1"
  OLD="`dirname $NEW`/`basename $NEW .new`"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "`cat $OLD | md5sum`" = "`cat $NEW | md5sum`" ]; then # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}

preserve_perms() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  if [ -e $OLD ]; then
    cp -a $OLD ${NEW}.incoming
    cat $NEW > ${NEW}.incoming
    mv ${NEW}.incoming $NEW
  fi
  config $NEW
}

preserve_perms etc/rc.d/rc.x2goserver.new
config etc/x2go/x2goagent.options.new
config etc/x2go/x2goserver.conf.new

# Start the database
if [ -x /usr/sbin/x2godbadmin ]; then
  /usr/sbin/x2godbadmin --createdb
fi

# Add x2goserver to rc.local
echo "Adding rc.x2goserver entry in rc.local..."
if [ ! -f /etc/rc.d/rc.local ]; then
  echo "Nothing to do: /etc/rc.d/rc.local not found"
else
 if ! grep -q "rc.x2goserver start" /etc/rc.d/rc.local && \
  grep --quiet '^x2gouser:' /etc/passwd && \
   grep --quiet '^x2gouser:' /etc/group; then
cat >> /etc/rc.d/rc.local << EOF

# Start X2Go remote desktop daemon.
#if [ -x /etc/rc.d/rc.x2goserver ]; then
#  sh /etc/rc.d/rc.x2goserver start
#fi

EOF
echo "New entry added in rc.local"
else
  echo "Nothing to do: rc.x2goserver already in /etc/rc.d/rc.local"
 fi
fi

echo "Adding rc.x2goserver entry in rc.local.shutdown..."
if [ ! -f /etc/rc.d/rc.local_shutdown ]; then
  echo "Nothing to do: /etc/rc.d/rc.local_shutdown not found"
else
 if ! grep -q "rc.x2goserver stop" /etc/rc.d/rc.local_shutdown  && \
  grep --quiet '^x2gouser:' /etc/passwd && \
   grep --quiet '^x2gouser:' /etc/group; then
cat >> /etc/rc.d/rc.local_shutdown << EOF

# Stop X2Go remote desktop daemon.
#if [ -x /etc/rc.d/rc.x2goserver ]; then
#  sh /etc/rc.d/rc.x2goserver stop
#fi

EOF
echo "New entry added in rc.local_shutdown"
 else
  echo "Nothing to do: rc.x2goserver already in /etc/rc.d/rc.local_shutdown"
 fi
fi

# Some pimp
if [ -f /usr/bin/tput ] && \
   grep --quiet '^x2gouser:' /etc/passwd && \
    grep --quiet '^x2gouser:' /etc/group ; then
  /usr/bin/tput bold
  echo ""
  echo "x2gouser will run as:"
  echo ""
  echo "User: x2gouser"
  echo "User ID: [`grep '^x2gouser:' /etc/passwd | awk -F : '{print $3}'`]"
  echo "Group: x2gouser"
  echo "Group ID: [`grep '^x2gouser:' /etc/group | awk -F : '{print $3}'`]"
  echo "Home: /var/lib/x2go"
  echo "Login shell: /bin/false"
  echo "Real name: X2Go user"
  echo "Expire date: never"
  echo "Password: _blank_"
  echo ""
  /usr/bin/tput sgr0
else
 if grep --quiet '^x2gouser:' /etc/passwd && \
     grep --quiet '^x2gouser:' /etc/group ; then
  echo ""
  echo "x2gouser will run as:"
  echo ""
  echo "User: x2gouser"
  echo "User ID: [`grep '^x2gouser:' /etc/passwd | awk -F : '{print $3}'`]"
  echo "Group: x2gouser"
  echo "Group ID: [`grep '^x2gouser:' /etc/group | awk -F : '{print $3}'`]"
  echo "Home: /var/lib/x2go"
  echo "Login shell: /bin/false"
  echo "Real name: X2Go user"
  echo "Expire date: never"
  echo "Password: _blank_"
  echo ""
 fi
fi

# Some more pimp
if [ -f /usr/bin/tput ] && \
   grep --quiet '^x2goprint:' /etc/passwd && \
    grep --quiet '^x2goprint:' /etc/group ; then
  /usr/bin/tput bold
  echo ""
  echo "x2goprint will run as:"
  echo ""
  echo "User: x2goprint"
  echo "User ID: [`grep '^x2goprint:' /etc/passwd | awk -F : '{print $3}'`]"
  echo "Group: x2goprint"
  echo "Group ID: [`grep '^x2goprint:' /etc/group | awk -F : '{print $3}'`]"
  echo "Home: /var/spool/x2go"
  echo "Login shell: /bin/false"
  echo "Real name: X2Go print"
  echo "Expire date: never"
  echo "Password: _blank_"
  echo ""
  /usr/bin/tput sgr0
else
 if grep --quiet '^x2goprint:' /etc/passwd && \
     grep --quiet '^x2goprint:' /etc/group ; then
  echo ""
  echo "x2goprint will run as:"
  echo ""
  echo "User: x2goprint"
  echo "User ID: [`grep '^x2goprint:' /etc/passwd | awk -F : '{print $3}'`]"
  echo "Group: x2goprint"
  echo "Group ID: [`grep '^x2goprint:' /etc/group | awk -F : '{print $3}'`]"
  echo "Home: /var/spool/x2go"
  echo "Login shell: /bin/false"
  echo "Real name: X2Go print"
  echo "Expire date: never"
  echo "Password: _blank_"
  echo ""
 fi
fi

if [ -x /usr/bin/update-desktop-database ]; then
  /usr/bin/update-desktop-database -q usr/share/applications >/dev/null 2>&1
fi

if [ -x /usr/bin/update-mime-database ]; then
  /usr/bin/update-mime-database usr/share/mime >/dev/null 2>&1
fi

