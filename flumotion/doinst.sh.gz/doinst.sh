config() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "$(cat $OLD | md5sum)" = "$(cat $NEW | md5sum)" ]; then
  # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}
config etc/flumotion/workers/default.xml.new
config etc/flumotion/managers/default/planet.xml.new

if [ -x /usr/bin/update-desktop-database ]; then
  /usr/bin/update-desktop-database -q usr/share/applications >/dev/null 2>&1
fi

if [ -x /usr/bin/update-mime-database ]; then
  /usr/bin/update-mime-database usr/share/mime >/dev/null 2>&1
fi

if [ -e usr/share/icons/hicolor/icon-theme.cache ]; then
  if [ -x /usr/bin/gtk-update-icon-cache ]; then
    /usr/bin/gtk-update-icon-cache usr/share/icons/hicolor >/dev/null 2>&1
  fi
fi

# Some pimp
if [ -f /usr/bin/tput ] && \
   grep --quiet '^flumotion:' /etc/passwd && \
    grep --quiet '^flumotion:' /etc/group ; then
  /usr/bin/tput bold
  echo ""
  echo "flumotion will run as:"
  echo ""
  echo "User: flumotion"
  echo "User ID: [`grep '^flumotion:' /etc/passwd | awk -F : '{print $3}'`]"
  echo "Group: flumotion"
  echo "Group ID: [`grep '^flumotion:' /etc/group | awk -F : '{print $3}'`]"
  echo "Home: /var/run/flumotion"
  echo "Login shell: /bin/false"
  echo "Real name: Flumotion Streamer Server"
  echo "Expire date: never"
  echo "Password: _none_"
  echo ""
  /usr/bin/tput sgr0
else
 if grep --quiet '^flumotion:' /etc/passwd && \
     grep --quiet '^flumotion:' /etc/group ; then
  echo ""
  echo "flumotion will run as:"
  echo ""
  echo "User: flumotion"
  echo "User ID: [`grep '^flumotion:' /etc/passwd | awk -F : '{print $3}'`]"
  echo "Group: flumotion"
  echo "Group ID: [`grep '^flumotion:' /etc/group | awk -F : '{print $3}'`]"
  echo "Home: /var/run/flumotion"
  echo "Login shell: /bin/false"
  echo "Real name: Flumotion Streamer Server"
  echo "Expire date: never"
  echo "Password: _none_"
  echo ""
 fi
fi

