config() {
  NEW="$1"
  OLD="$(dirname $NEW)/$(basename $NEW .new)"
  # If there's no config file by that name, mv it over:
  if [ ! -r $OLD ]; then
    mv $NEW $OLD
  elif [ "$(cat $OLD | md5sum)" = "$(cat $NEW | md5sum)" ]; then
  # toss the redundant copy
    rm $NEW
  fi
  # Otherwise, we leave the .new copy for the admin to consider...
}

# Keep same perms on rc.uptimed.new:
if [ -e etc/rc.d/rc.uptimed ]; then
  cp -a etc/rc.d/rc.uptimed etc/rc.d/rc.uptimed.new.incoming
  cat etc/rc.d/rc.uptimed.new > etc/rc.d/rc.uptimed.new.incoming
  mv etc/rc.d/rc.uptimed.new.incoming etc/rc.d/rc.uptimed.new
fi
# Then go for it
config etc/rc.d/rc.uptimed.new

# For single config files
config etc/uptimed.conf.new

# Create useable database
echo -n "Creatind useable database for uptime record daemon (uptimed)..."
( cd usr/sbin ; uptimed -b )
echo ""

( cd usr/lib64 ; rm -rf libuptimed.so )
( cd usr/lib64 ; ln -sf libuptimed.so.0.0.0 libuptimed.so )
( cd usr/lib64 ; rm -rf libuptimed.so.0 )
( cd usr/lib64 ; ln -sf libuptimed.so.0.0.0 libuptimed.so.0 )
